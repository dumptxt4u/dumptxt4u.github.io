from pydoc import text
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext
import csv
from datetime import datetime
import re
import random
import subprocess
import os
import string

class MCQGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("🚀 Ultimate MCQ Generator - Ultra Stable Parser v2")
        self.root.geometry("1480x960")
       
        self.questions = []  # (qid, question, a, b, c, d, correct)
        self.session_code = self.generate_session_code()
       
        tk.Label(root, text="🚀 Ultimate MCQ Generator", font=("Arial", 20, "bold")).pack(pady=10)
        tk.Label(root, text=f"Session Code: {self.session_code}", font=("Consolas", 12, "bold"), fg="darkblue").pack(pady=2)
       
        # Toolbar
        toolbar = tk.Frame(root)
        toolbar.pack(pady=8, fill="x")
       
        tk.Button(toolbar, text="📂 Import .tex", bg="#2196F3", fg="white", width=15, command=self.load_tex_file).pack(side="left", padx=4)
        tk.Button(toolbar, text="📋 Show Example", bg="#00BCD4", fg="white", width=15, command=self.show_example_tex).pack(side="left", padx=4)
        tk.Button(toolbar, text="💾 Export .tex", bg="#4CAF50", fg="white", width=15, command=self.save_as_tex).pack(side="left", padx=4)
       
        tk.Button(toolbar, text="🔀 Randomize", bg="#9C27B0", fg="white", width=15, command=self.randomize_and_export).pack(side="left", padx=4)
        tk.Button(toolbar, text="💾 Export CSV", bg="#FF9800", fg="white", width=15, command=self.export_csv).pack(side="left", padx=4)
        tk.Button(toolbar, text="🗑️ Clear All", bg="#f44336", fg="white", width=12, command=self.clear_all).pack(side="left", padx=4)
        tk.Button(toolbar, text="📊 Generate Answers", bg="#9C27B0", fg="white", width=18, command=self.show_answers_table).pack(side="left", padx=4)
        tk.Button(toolbar, text="💾 Download Answers", bg="#607D8B", fg="white", width=20, command=self.save_answers_tex).pack(side="left", padx=4)
      
        # Input Frame
        input_frame = tk.LabelFrame(root, text="Add / Edit Question", font=("Arial", 11, "bold"), padx=10, pady=10)
        input_frame.pack(padx=15, pady=8, fill="x")
       
        tk.Label(input_frame, text="QID:", font=("Arial", 10, "bold")).grid(row=0, column=0, sticky="w")
        self.qid_entry = tk.Entry(input_frame, width=12)
        self.qid_entry.grid(row=0, column=1, sticky="w", padx=5)
       
        tk.Label(input_frame, text="Question:", font=("Arial", 10, "bold")).grid(row=1, column=0, sticky="nw", pady=5)
        self.question_text = scrolledtext.ScrolledText(input_frame, width=135, height=4)
        self.question_text.grid(row=1, column=1, columnspan=6, pady=5)
       
        self.options = {}
        for i, opt in enumerate(['A', 'B', 'C', 'D']):
            tk.Label(input_frame, text=f"({opt})", font=("Arial", 10, "bold")).grid(row=2+i, column=0, sticky="w", pady=2)
            self.options[opt] = tk.Entry(input_frame, width=110)
            self.options[opt].grid(row=2+i, column=1, columnspan=6, sticky="w", pady=2)
       
        tk.Label(input_frame, text="Correct Ans:", font=("Arial", 10, "bold")).grid(row=6, column=0, sticky="w", pady=5)
        self.correct_var = tk.StringVar()
        self.correct_combo = ttk.Combobox(input_frame, textvariable=self.correct_var, values=['A','B','C','D'], width=10)
        self.correct_combo.grid(row=6, column=1, sticky="w")
       
        btn_frame = tk.Frame(input_frame)
        btn_frame.grid(row=7, column=1, pady=10)
        tk.Button(btn_frame, text="➕ Add", bg="#4CAF50", fg="white", command=self.add_question).pack(side="left", padx=5)
        tk.Button(btn_frame, text="✏️ Update", bg="#FF9800", fg="white", command=self.update_selected).pack(side="left", padx=5)
        tk.Button(btn_frame, text="🗑️ Delete", bg="#f44336", fg="white", command=self.delete_selected).pack(side="left", padx=5)
        tk.Button(btn_frame, text="Clear Fields", command=self.clear_fields).pack(side="left", padx=5)
       
        # Search Frame
        search_frame = tk.Frame(root)
        search_frame.pack(padx=20, pady=5, fill="x")
        tk.Label(search_frame, text="🔍 Search:").pack(side="left")
        self.search_var = tk.StringVar()
        tk.Entry(search_frame, textvariable=self.search_var, width=50).pack(side="left", padx=5)
        tk.Button(search_frame, text="Search", command=self.search_questions).pack(side="left")
        tk.Button(search_frame, text="Show All", command=self.refresh_tree).pack(side="left", padx=5)
       
        tk.Label(root, text="Loaded Questions (Double Click to Edit)", font=("Arial", 12, "bold")).pack(anchor="w", padx=20, pady=(10,0))
       
        self.tree = ttk.Treeview(root, columns=("QID", "Question", "A", "B", "C", "D", "Ans"), show="headings", height=18)
        cols_width = [50, 480, 140, 140, 140, 140, 60]
        for col, w in zip(self.tree["columns"], cols_width):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=w)
       
        scrollbar = ttk.Scrollbar(root, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(padx=20, pady=5, fill="both", expand=True, side="left")
        scrollbar.pack(side="right", fill="y")
       
        self.tree.bind("<Double-1>", self.on_double_click)
       
        self.status = tk.Label(root, text="Ready | 0 Questions", fg="blue", font=("Arial", 10, "bold"))
        self.status.pack(pady=5)

    def generate_session_code(self):
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(8))

    def clean_text(self, text: str) -> str:
        text = re.sub(r'\\\$', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    # ==================== UNCHANGED AS REQUESTED ====================
    def load_tex_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("LaTeX Files", "*.tex *.txt")])
        if not file_path:
            return

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            self.questions.clear()
            qid = 1

            # Main pattern: Find each question block starting with \item ... \begin{enumerate} ... %correct
            pattern = r'\\item\s+(.+?)\s*\\begin\{enumerate\}[^}]*\}(.+?)\\end\{enumerate\}  \s*%correct\s*([a-d])'
            matches = re.findall(pattern, content, re.DOTALL | re.IGNORECASE)

            for q_text, opts_block, correct_letter in matches:
                question = self.clean_text(q_text)

                # Extract 4 choices
                choice_matches = re.findall(r'\\item\s+(.+?)(?=\s*\\item|\s*\\end)', opts_block, re.DOTALL)
                choices = [self.clean_text(ch) for ch in choice_matches]

                # Ensure exactly 4 choices
                while len(choices) < 4:
                    choices.append("")
                choices = choices[:4]

                correct = correct_letter.upper()

                if question and len(choices) == 4:
                    self.questions.append((str(qid), question, choices[0], choices[1], choices[2], choices[3], correct))
                    qid += 1

            # Fallback: If main pattern fails, try line-by-line approach
            if len(self.questions) == 0:
                self.fallback_parser(content)

            self.refresh_tree()
            messagebox.showinfo("Success", 
                f"✅ Successfully Loaded {len(self.questions)} Questions!\n"
                "Improved Parser v2 - Handles your exact format very well.")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to parse:\n{str(e)}")

    def fallback_parser(self, content):
        lines = content.splitlines()
        i = 0
        qid = 1
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith(r'\item ') and r'\begin{enumerate}' not in line:
                question = self.clean_text(line[6:])
                choices = []
                i += 1
                while i < len(lines) and not lines[i].strip().startswith(r'\end{enumerate}'):
                    if lines[i].strip().startswith(r'\item '):
                        ch = self.clean_text(lines[i].strip()[6:])
                        choices.append(ch)
                    i += 1
                
                correct = ""
                for j in range(i, min(i+10, len(lines))):
                    if '%correct' in lines[j].lower():
                        match = re.search(r'%correct\s*([a-d])', lines[j], re.IGNORECASE)
                        if match:
                            correct = match.group(1).upper()
                        break
                
                if question and len(choices) >= 4:
                    choices = choices[:4]
                    self.questions.append((str(qid), question, choices[0], choices[1], choices[2], choices[3], correct))
                    qid += 1
            i += 1

    def generate_answers_table(self):
        if not self.questions:
            return "No questions loaded."
        
        table = r"""\begin{center}
{\Large \textbf{Answer Key}} \\[10pt]
\textbf{Session Code:} \texttt{""" + self.session_code + r"""} \\[15pt]

\begin{tabular}{>{\bfseries}c c}
\toprule
\textbf{Question} & \textbf{Correct Answer} \\
\midrule
"""
        for i, q in enumerate(self.questions, start=1):
            correct = q[6].strip().upper() if len(q) > 6 and q[6] else "?"
            table += f"{i} & ({correct}) \\\\\n"
        
        table += r"""\bottomrule
\end{tabular}
\end{center}"""
        return table

    def save_answers_tex(self):
        if not self.questions:
            messagebox.showwarning("Empty", "No questions loaded!")
            return
        
        file_path = filedialog.asksaveasfilename(
            defaultextension=".tex",
            filetypes=[("LaTeX Files", "*.tex")],
            initialname=f"Answer_Key_{self.session_code}.tex"
        )
        if not file_path: return
        
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(r"""\documentclass{article}
\usepackage{booktabs}
\usepackage{array}
\usepackage{geometry}
\geometry{a4paper, margin=1in}

\begin{document}

\title{Answer Key}
\maketitle

""")
                f.write(self.generate_answers_table())
                f.write(r"\end{document}")
            messagebox.showinfo("Success", f"Answer Key saved successfully!\n\nFile: {file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save:\n{str(e)}")

    def show_answers_table(self):
        if not self.questions:
            messagebox.showwarning("Empty", "No questions loaded!")
            return
        
        table_text = self.generate_answers_table()
        
        win = tk.Toplevel(self.root)
        win.title(f"📊 Answer Key - {self.session_code}")
        win.geometry("850x700")
        
        txt = scrolledtext.ScrolledText(win, font=("Consolas", 11), wrap=tk.WORD)
        txt.pack(padx=20, pady=10, fill="both", expand=True)
        txt.insert("1.0", table_text)
        txt.config(state="disabled")
        
        btn_frame = tk.Frame(win)
        btn_frame.pack(pady=15)
        
        tk.Button(btn_frame, text="📋 Copy All to Clipboard", bg="#4CAF50", fg="white", 
                 font=("Arial", 10, "bold"), width=28,
                 command=lambda: self.copy_to_clipboard(table_text)).pack(side="left", padx=12)
        
        tk.Button(btn_frame, text="Close", bg="#f44336", fg="white", 
                 width=15, command=win.destroy).pack(side="left", padx=12)

    def copy_to_clipboard(self, text):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("✅ Copied", "Answer Key copied to clipboard!")

    def save_as_tex(self):
        if not self.questions: 
            return messagebox.showwarning("Empty", "No questions!")
        file_path = filedialog.asksaveasfilename(defaultextension=".tex", filetypes=[("LaTeX", "*.tex")])
        if not file_path: return
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(r"""\documentclass{article}
\usepackage{enumitem}
\usepackage{amsmath}
\usepackage{geometry}
\usepackage{booktabs}
\usepackage{array}
\geometry{a4paper, margin=1in}

\begin{document}

\title{MCQ Questions}
\maketitle

\textbf{Session Code:} \texttt{""" + self.session_code + r"""}

\section{Questions}

\begin{enumerate}
""")
                for i, q in enumerate(self.questions, 1):
                    f.write(f"\n% Question {i}\n")
                    f.write(f"\\item {q[1]}\n")
                    f.write(r"    \begin{enumerate}[label=(\alph*), nosep]" + "\n")
                    for opt in [q[2], q[3], q[4], q[5]]:
                        f.write(f"        \\item {opt}\n")
                    f.write(r"    \end{enumerate}" + "\n")
                    f.write(f"%correct {q[6].lower()}\n")
                
                f.write(r"\end{enumerate}")
                f.write(r"\newpage")
                f.write(r"\section*{Answer Key}")
                f.write("\n\n")
                f.write(self.generate_answers_table())
                f.write(r"\end{document}")
            messagebox.showinfo("Success", f"Full paper with Answer Key saved!\n\n{file_path}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    # ==================== Other Methods ====================
    def show_example_tex(self):
        example = r"""\item If a kite is flying at a height of $40\sqrt{3}$ metres from the level ground, attached to a string inclined at $60^\circ$ to the horizontal, then the length of the string is
    \begin{enumerate}[label=(\alph*), nosep]
        \item 80 m
        \item $60\sqrt{3}$ m
        \item $80\sqrt{3}$ m
        \item 120 m
    \end{enumerate}
%correct c"""
        win = tk.Toplevel(self.root)
        win.title("Example Format")
        win.geometry("1100x600")
        txt = scrolledtext.ScrolledText(win, font=("Consolas", 10))
        txt.pack(padx=10, pady=10, fill="both", expand=True)
        txt.insert("1.0", example)

    def add_question(self):
        qid = self.qid_entry.get().strip() or str(len(self.questions)+1)
        question = self.question_text.get("1.0", tk.END).strip()
        if not question: return messagebox.showwarning("Error", "Question required!")
        opts = [self.options[k].get().strip() for k in 'ABCD']
        self.questions.append((qid, question, opts[0], opts[1], opts[2], opts[3], self.correct_var.get()))
        self.refresh_tree()
        self.clear_fields()

    def update_selected(self):
        selected = self.tree.selection()
        if not selected: return
        idx = self.tree.index(selected[0])
        qid = self.qid_entry.get().strip() or self.questions[idx][0]
        question = self.question_text.get("1.0", tk.END).strip()
        opts = [self.options[k].get().strip() for k in 'ABCD']
        self.questions[idx] = (qid, question, opts[0], opts[1], opts[2], opts[3], self.correct_var.get())
        self.refresh_tree()

    def delete_selected(self):
        selected = self.tree.selection()
        if selected and messagebox.askyesno("Delete", "Delete this question?"):
            idx = self.tree.index(selected[0])
            del self.questions[idx]
            self.refresh_tree()

    def on_double_click(self, event):
        selected = self.tree.selection()
        if not selected: return
        idx = self.tree.index(selected[0])
        q = self.questions[idx]
        self.qid_entry.delete(0, tk.END)
        self.qid_entry.insert(0, q[0])
        self.question_text.delete("1.0", tk.END)
        self.question_text.insert("1.0", q[1])
        for i, letter in enumerate('ABCD'):
            self.options[letter].delete(0, tk.END)
            self.options[letter].insert(0, q[i+2])
        self.correct_var.set(q[6])

    def search_questions(self):
        term = self.search_var.get().lower()
        for item in self.tree.get_children(): self.tree.delete(item)
        for q in self.questions:
            if term in q[1].lower() or any(term in str(x).lower() for x in q[2:6]):
                self.tree.insert("", "end", values=(q[0], q[1][:85]+"..." if len(q[1])>85 else q[1],
                                                  q[2][:28], q[3][:28], q[4][:28], q[5][:28], q[6] or "-"))

    def refresh_tree(self):
        for item in self.tree.get_children(): self.tree.delete(item)
        for q in self.questions:
            self.tree.insert("", "end", values=(
                q[0], q[1][:85] + "..." if len(q[1]) > 85 else q[1],
                q[2][:28], q[3][:28], q[4][:28], q[5][:28], q[6] or "-"
            ))
        self.status.config(text=f"✅ {len(self.questions)} Questions Loaded")

    def clear_fields(self):
        self.qid_entry.delete(0, tk.END)
        self.question_text.delete("1.0", tk.END)
        for e in self.options.values(): e.delete(0, tk.END)
        self.correct_var.set("")

    def clear_all(self):
        if messagebox.askyesno("Clear All", "Delete all questions?"):
            self.questions.clear()
            self.refresh_tree()

    def export_csv(self):
        if not self.questions: return
        filename = f"mcq_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(["QID", "Question", "A", "B", "C", "D", "Correct"])
            writer.writerows(self.questions)
        messagebox.showinfo("Success", f"Saved: {filename}")

    def randomize_and_export(self):
        if not self.questions: return
        random.shuffle(self.questions)
        for i in range(len(self.questions)):
            self.questions[i] = (str(i+1),) + self.questions[i][1:]
        self.refresh_tree()
        self.save_as_tex()

    def generate_pdf(self):
        if not self.questions: return messagebox.showwarning("Empty", "No questions!")
        self.save_as_tex()

if __name__ == "__main__":
    root = tk.Tk()
    app = MCQGenerator(root)
    root.mainloop()
